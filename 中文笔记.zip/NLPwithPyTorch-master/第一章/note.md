# 本章概要
主要介绍了下列知识点
1. 监督学习的概念；
2. 计算图（computational graph）的概念；
3. 若干术语：observation, target, model(function), parameter(weight), prediction, loss function, representation, learning/training, inference;
4. one-hot encoding;
5. TF 与 TF-IDF;
6. PyTorch的基本使用,包括tensor的声明、运算操作等;
